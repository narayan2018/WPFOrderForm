﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrdersClient.Models;
using OrdersClient.Services;
using OrdersClient.ViewModels;

namespace OrdersClient.UnitTests.ViewModels
{

    [TestClass]
    public class MainWindowViewModelTests 
    {
        [TestMethod]
        public void SearchTextContainsInvalidCharacters_SearchCannotBeExecuted()
        {
            var obj = new MainWindowViewModel(new OrderService());
            // Arrange
            // Act
            obj.SearchBoxText = "-";
            var result=obj.CanExecuteSearch();
            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void SearchTextIsNegativNumber_SearchCannotBeExecuted()
        {

            // Arrange
            var obj = new MainWindowViewModel(new OrderService());
            // Act
            obj.SearchBoxText = "-1";
            var result = obj.CanExecuteSearch();
            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void SearchTextIsValidUserId_SearchCanBeExecuted()
        {
            // Arrange
            var obj = new MainWindowViewModel(new OrderService());
            // Act
            obj.SearchBoxText = "1";
            var result = obj.CanExecuteSearch();
            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void SearchForOders_ValidUserId_CurrentUserVMContainsOrdersWithCorrectUserId()
        {
            // Arrange
            var testUser1 = CreateTestUser(1);
            var testUser2 = CreateTestUser(2);
            var testOrders = new[] {
                CreateTestOder(testUser1),
                CreateTestOder(testUser1),
                CreateTestOder(testUser2),
                CreateTestOder(testUser2),
                CreateTestOder(testUser1),
            };
            var viewModel = CreateSut(testOrders);

            // Act
            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void SearchForOders_ValidUser_TotalAmountSpentIsTheTotalSumOfAllOrders()
        {
            // Arrange
            var testUser1 = CreateTestUser(1);
            var testOrders = new[] {
                CreateTestOder(testUser1, priceInEuro: 5, amount: 1),
                CreateTestOder(testUser1, priceInEuro: 10, amount: 2),
                CreateTestOder(testUser1, priceInEuro: 3, amount: 5),
            };
            var viewModel = CreateSut(testOrders);
            // Act
            // Assert
            Assert.Fail();
        }


        private User CreateTestUser(int id)
        {
            return new User() { Id = id, FirstName = "User", LastName = id.ToString() };
        }

        private Order CreateTestOder(User user, int priceInEuro = 0, uint amount = 0)
        {
            return new Order() { User = user, ItemPriceInEuro = priceInEuro, ItemCount = amount };
        }

        private MainWindowViewModel CreateSut(IEnumerable<Order>? testOrders = null) 
        {
            return new MainWindowViewModel(new FakeOrderService(testOrders));
        }
    }
}
