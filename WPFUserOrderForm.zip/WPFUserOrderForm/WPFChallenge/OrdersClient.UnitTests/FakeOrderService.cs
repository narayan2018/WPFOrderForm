﻿using OrdersClient.Models;
using OrdersClient.Services;

namespace OrdersClient.UnitTests
{
    internal class FakeOrderService : IOrderService
    {
        private readonly IEnumerable<Order> _testOrders;

        public FakeOrderService(IEnumerable<Order>? testOrders)
        {
            _testOrders = testOrders ?? Enumerable.Empty<Order>();
        }

        public IEnumerable<Order> GetOrders()
        {
            return _testOrders;
        }
    }
}
