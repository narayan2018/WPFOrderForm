﻿namespace OrdersClient.Models;

class Order
{
    public int Id { get; set; }
    public User? User { get; set; }
    public string? ItemName { get; set; }
    public decimal ItemPriceInEuro { get; set; }
    public uint ItemCount { get; set; }
}

