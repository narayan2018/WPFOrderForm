﻿using OrdersClient.Models;

namespace OrdersClient.Services;

interface IOrderService
{
    IEnumerable<Order> GetOrders();
}

