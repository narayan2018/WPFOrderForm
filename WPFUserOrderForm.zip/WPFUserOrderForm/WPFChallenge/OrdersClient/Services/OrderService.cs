﻿using Bogus;
using OrdersClient.Models;

namespace OrdersClient.Services;

class OrderService : IOrderService
{
    private readonly Lazy<List<Order>> _orders;

    public OrderService()
    {
        _orders = new(GenerateOrders);
    }

    public IEnumerable<Order> GetOrders()
    {
        return _orders.Value;
    }

    private List<Order> GenerateOrders()
    {
        int numUsers = 200;

        var userFaker = new Faker<User>();
        userFaker.RuleFor(u => u.Id, f => f.UniqueIndex);
        userFaker.RuleFor(u => u.FirstName, f => f.Name.FirstName());
        userFaker.RuleFor(u => u.LastName, f => f.Name.LastName());
        userFaker.RuleFor(u => u.Email, f => f.Internet.Email());
        userFaker.RuleFor(u => u.Address, f => f.Address.FullAddress());

        var users = userFaker.Generate(numUsers);

        var orderFaker = new Faker<Order>();
        orderFaker.RuleFor(o => o.Id, f => f.UniqueIndex);
        orderFaker.RuleFor(o => o.ItemName, f => f.Commerce.Product());
        orderFaker.RuleFor(o => o.ItemCount, f => f.Commerce.Random.UInt(1, 13));
        orderFaker.RuleFor(o => o.ItemPriceInEuro, f => f.Commerce.Random.Decimal(0, 120));

        return users.SelectMany(u =>
        {
            orderFaker.RuleFor(o => o.User, _ => u);
            return orderFaker.Generate(Random.Shared.Next(3, 15));
        }).ToList();
    }
}


