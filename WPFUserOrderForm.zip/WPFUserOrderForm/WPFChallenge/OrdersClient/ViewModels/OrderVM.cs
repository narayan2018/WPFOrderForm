﻿
namespace OrdersClient.ViewModels;

class OrderVM
{
    public int Id { get; set; }
    public string? ItemName { get; set; }
    public decimal ItemPriceInEuro { get; set; }
    public uint ItemCount { get; set; }

    public decimal Total { get; set; }
}

