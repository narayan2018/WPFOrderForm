﻿namespace OrdersClient.ViewModels;

class CurrentUserVM
{
    public string? FullName { get; set; }
    public string? Email { get; set; }
    public string? Address { get; set; }
    public decimal TotalOrderPrice { get; set; }
    public List<OrderVM> Orders { get; set; } = new List<OrderVM>();
}
