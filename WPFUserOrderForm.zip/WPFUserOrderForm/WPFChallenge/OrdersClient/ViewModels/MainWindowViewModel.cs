﻿using OrdersClient.Services;
using OrdersClient.Utils;
using System.ComponentModel;
using System.Windows;

namespace OrdersClient.ViewModels;

class MainWindowViewModel : ViewModelBase,IDataErrorInfo
{
    private readonly IOrderService _orderService;

    public BindableCommand SearchOrdersCommand { get; }

    public MainWindowViewModel(IOrderService orderService)
    {
        _orderService = orderService;
        SearchOrdersCommand = new BindableCommand(SearchOrders, CanExecuteSearch);
        _currentUserVM = new CurrentUserVM();
        IsSearchButtonEnabled = true;
    }

    private CurrentUserVM _currentUserVM;
    public CurrentUserVM CurrentUserVM
    {
        get { return _currentUserVM; }
        set
        {
            _currentUserVM = value;
            RaisePropertyChanged("CurrentUserVM");
        }
    }

    private bool _isUserVisible;
    public bool IsUserVisible
    {
        get { return _isUserVisible; }
        set
        {
            _isUserVisible = value;
            RaisePropertyChanged("IsUserVisible");
        }
    }
    private bool _isSearchButtonEnabled;
    public bool IsSearchButtonEnabled
    {
        get { return _isSearchButtonEnabled; }
        set
        {
            _isSearchButtonEnabled = value;
            RaisePropertyChanged("IsSearchButtonEnabled");
        }
    }

    private string _searchBoxText = string.Empty;
    public string SearchBoxText
    {
        get { return _searchBoxText; }
        set
        {
            _searchBoxText = value;
            EnableDisableSearchButton(_searchBoxText);
            RaisePropertyChanged("SearchBoxText");

        }
    }

    public string Error => throw new NotImplementedException();

    public string this[string fieldName]
    {
        get
        {
            string message = string.Empty;
            if(!string.IsNullOrEmpty(SearchBoxText))
            {
                
                if ("SearchBoxText" == fieldName)
                {
                    if (String.IsNullOrEmpty(SearchBoxText) || !IsValidUserId(_searchBoxText))
                    {
                        message = "Please enter a valid user Id";
                    }
                }
            }
            
            return message;
        }
    }

    private void EnableDisableSearchButton(string searchBox)
    {
        IsSearchButtonEnabled = IsValidUserId(searchBox) ? true : false;
        RaisePropertyChanged("IsSearchButtonEnabled");
    }

    /// <summary>
    /// Validate User id
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    private bool IsValidUserId(string userId)
    {
        bool result = true;
        int id;

        bool isValid = Int32.TryParse(userId, out id);
        if (userId == null || userId.Trim().Length == 0 || id <= 0)
        {
            result = false;
        }
        return result;
    }

    /// <summary>
    /// Search user for valid id
    /// </summary>
    /// <param name="parameter"></param>
    private void SearchOrders(object parameter)
    {
        if (IsValidUserId(_searchBoxText))
        {
            int userId = Int32.Parse(_searchBoxText);
            SearchOrdersDetails(userId);
        }
    }

    /// <summary>
    /// Search User & get orders
    /// </summary>
    /// <param name="userId"></param>
    private void SearchOrdersDetails(int userId)
    {
        var orders = _orderService.GetOrders();
        var userOrder = orders.Where(x => x.User?.Id == userId).ToList();
        var currentUserVM = new CurrentUserVM();
        if (userOrder != null && userOrder.Count > 0)
        {
            var order = userOrder.FirstOrDefault();
            var userOdersList = new List<OrderVM>();
            foreach (var item in userOrder)
            {
                userOdersList.Add(new OrderVM
                {
                    Id = item.Id,
                    ItemName = item.ItemName,
                    ItemCount = item.ItemCount,
                    ItemPriceInEuro = item.ItemPriceInEuro,
                    Total = item.ItemCount * item.ItemPriceInEuro,
                });
            }
            if (userOrder != null && userOdersList.Count > 0)
            {
                currentUserVM.Address = userOrder[0]?.User?.Address;
                currentUserVM.FullName = userOrder[0]?.User?.FirstName + " " + userOrder[0]?.User?.LastName;
                currentUserVM.Email = userOrder[0]?.User?.Email;
                currentUserVM.TotalOrderPrice = userOdersList.Sum(x => x.Total);
                currentUserVM.Orders = userOdersList;
                IsUserVisible = true;
            }
        }
        else
        {
            IsUserVisible = false;
            currentUserVM.Address = null;
            currentUserVM.FullName = null;
            currentUserVM.Email = null;
            currentUserVM.TotalOrderPrice = 0;
            MessageBox.Show("A user with the given ID does not exist.", "User Search", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        CurrentUserVM = currentUserVM;
        RaisePropertyChanged("CurrentUserVM");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public bool CanExecuteSearch()
    {
        return IsValidUserId(SearchBoxText);
    }
}
