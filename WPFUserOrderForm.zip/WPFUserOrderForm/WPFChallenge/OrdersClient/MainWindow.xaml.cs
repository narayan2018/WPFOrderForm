﻿using OrdersClient.Services;
using OrdersClient.ViewModels;
using System.Windows;

namespace OrdersClient
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            IOrderService orderService = new OrderService();
            var vm = new MainWindowViewModel(orderService);
            this.DataContext = vm;
        }
    }
}