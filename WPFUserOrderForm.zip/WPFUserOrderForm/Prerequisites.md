# WPF Challenge prerequisites

To attempt the challenge, you need to have the following software installed on your system:

1. The [.NET 8 SDK](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)
2. An IDE to change the code files. In theory VS-Code would be enough, but we recommend using full [Visual Studio](https://visualstudio.microsoft.com/de/downloads/) because of the WPF/XAML features it provides.
