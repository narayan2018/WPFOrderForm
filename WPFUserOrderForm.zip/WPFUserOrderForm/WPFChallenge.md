# Krones Employment Challenge

This directory contains a simple .NET WPF application that can be used to query orders and other information of a given user.
Unfortunately, most of the code is lost because someone forgot to push the changes to the remote repository...

The goal of the challenge is to re-implement the missing code in a way that it meets the requirements from the following user story.

---

## User Story

**As a Sales Engineer, I would like to see a list with every order for a given user, so that I can get an understanding of the things users buy from our shop.**

Create a simple Windows WPF application where the user can query user details and the user's list of orders by entering a user-ID.

### Acceptance Criteria

- When opening the app, a form is shown where the user can enter a user-ID.
- The user-ID text field accepts only positive integer values. If the user enters a non-integer value, the form should display a red border and a validation error message. The validation must happen for every keystroke, not just on lost focus.
- The app has a "search" button. When clicked, the user information of the user with the given user-ID is queried and displayed.
- The search button is disabled if the user-ID field is empty or contains an invalid value.
- When the user searches for a user ID that does not exist, a message is shown that informs them that a user with the given ID does not exist.
- The search function can also be triggered by pressing the enter key on the keyboard (if a valid user ID has been entered).
- The user data fields are hidden until a successful search is made.
- After a successful search, the following information is shown:
  - Full name, email, and address of the user with the given ID.
  - The total sum of all orders the user made (in Euro, 2 decimal places).
  - A list of orders for the given user. For every order, the following information has to be displayed (see mockup for details):
    - Order ID
    - Item name
    - Amount of items
    - Price per item in Euro (2 decimal places)
    - Total price (2 decimal places)
- When clicking the search button after another user ID was entered, the data of the new user is shown.
- If a user ID that does not exist is entered, all data of the previous user needs to be hidden/removed.
- If the orders do not fit on the screen, a scroll viewer is shown that allows scrolling the orders vertically.
- Test the main business logic of the app using unit tests.

### Technical Requirements

#### Backend

- The data access layer is represented by the `IOrderService` interface. You can use this service to query the total list of orders in the system. The code that generates the orders already exists. Inject the `OrderService` as an implementation of `IOrderService` in the constructor of your ViewModel.
- Implement everything in the MVVM architectural pattern.
- Don't use third-party libraries. Implement the `BindableCommand` and `ViewModelBase` classes and needed value converters yourself (keep it simple).
- Unit tests already exist in the `OrderClient.UnitTest` project. Complete them to test the core logic of your app.

#### Frontend

Implement the frontend by using out-of-the-box WPF/XAML only. Don't use third-party styling libraries. Try to style the application as close as you can to the following mockup:

![Mockup](mockup.png)

Good luck and happy coding!